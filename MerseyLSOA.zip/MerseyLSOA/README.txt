Files:
england_low_soa_2001.shx
wfsrequest.txt
england_low_soa_2001.prj
england_low_soa_2001.cst
england_low_soa_2001.dbf
england_low_soa_2001.shp

Areas:
Merseyside

This data is provided with the support of the ESRC and JISC and uses boundary material which is copyright of the Crown, the Post Office and the ED-LINE consortium.